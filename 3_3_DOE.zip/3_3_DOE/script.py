import os
import re
import pandas as pd

PATH = r"C:\Users\Antonio\Desktop\DoE copia\run"

# Nome file esempio: Large_run2_950.csv
FILENAME_RE = re.compile(
    r"^(?P<page>[A-Za-z]+)_run(?P<run>\d+)_(?P<ctt>\d+)\.csv$",
    re.IGNORECASE
)

rows_out = []

for fname in os.listdir(PATH):
    if not fname.lower().endswith(".csv"):
        continue

    m = FILENAME_RE.match(fname)
    if not m:
        print(f"[SKIP] Nome file non valido: {fname}")
        continue

    page = m.group("page").lower()   # small / large / xlarge
    run = int(m.group("run"))        # 1..3
    ctt = int(m.group("ctt"))        # 475 / 950 / 1425

    df = pd.read_csv(os.path.join(PATH, fname))

    # Tieni solo richieste andate a buon fine
    df_ok = df[df["success"] == True].copy()

    if df_ok.empty:
        print(f"[WARN] Nessuna richiesta OK in {fname}")
        continue

    # (sicurezza) se ci sono più label, tieni quella dominante
    if df_ok["label"].nunique() > 1:
        main_label = df_ok["label"].value_counts().idxmax()
        df_ok = df_ok[df_ok["label"] == main_label]

    # Response Time (Elapsed)
    elapsed_mean = df_ok["elapsed"].mean()

    # Latency
    latency_mean = df_ok["Latency"].mean()

    # Throughput (req/s)
    t_min = df_ok["timeStamp"].min()
    t_max = df_ok["timeStamp"].max()
    duration_s = (t_max - t_min) / 1000.0

    throughput = len(df_ok) / duration_s if duration_s > 0 else None

    rows_out.append({
        "Page": page,
        "Run": run,
        "CTT": ctt,
        "Response Time (Elapsed) [ms]": round(elapsed_mean, 2),
        "Latency [ms]": round(latency_mean, 2),
        "Throughput [req/s]": round(throughput, 3),
        "Samples": int(len(df_ok)),
        "SourceFile": fname
    })

# Ordina per DoE
out_df = (
    pd.DataFrame(rows_out)
      .sort_values(by=["CTT", "Page", "Run"])
      .reset_index(drop=True)
)

out_df.to_csv("Y.csv", index=False)
print("Creato Y.csv con", len(out_df), "righe")
