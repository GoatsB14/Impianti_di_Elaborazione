import pandas as pd
import os

# ============================================================
# CONFIGURAZIONE DEI TEST
# ============================================================

TESTS = [
    {
        "name": "Test 1",
        "csv": "fairness_test1.csv",
        "fair_small": 750,
        "fair_medium": 500,
        "fair_large": 250,
    },
    {
        "name": "Test 2",
        "csv": "fairness_test2.csv",
        "fair_small": 250,
        "fair_medium": 500,
        "fair_large": 750,
    },
    {
        "name": "Test 3",
        "csv": "fairness_test3.csv",
        "fair_small": 750,
        "fair_medium": 500,
        "fair_large": 250,
    }
]

# Etichette dentro la colonna 2 del CSV
LABEL_SMALL = "HTTP Request Small"
LABEL_MEDIUM = "HTTP Request Medium"
LABEL_LARGE = "HTTP Request Large"

# ============================================================
# FUNZIONE THROUGHPUT
# ============================================================

def calc_throughput(df_resource):
    if df_resource.empty:
        return 0.0
    
    start = df_resource["timestamp"].min()
    end = df_resource["timestamp"].max()
    duration_s = (end - start) / 1000.0

    total_requests = len(df_resource)
    return total_requests / duration_s if duration_s > 0 else 0.0

# ============================================================
# ESECUZIONE TEST
# ============================================================

for t in TESTS:
    print("\n===========================================")
    print(f"       {t['name']} - {t['csv']}")
    print("===========================================")

    if not os.path.exists(t["csv"]):
        print(f"ERRORE: File {t['csv']} non trovato.")
        continue

    # IMPORTANTE: il CSV NON ha header
    df = pd.read_csv(t["csv"], header=None)

    # Assegno i nomi corretti alle colonne
    df.columns = [
        "timestamp",      # col 0
        "elapsed",        # col 1
        "label",          # col 2
        "responseCode",   # col 3
        "responseMsg",    # col 4
        "threadName",     # col 5
        "success",        # col 6
        "bytes",          # col 7
        "sentBytes",      # col 8
        "latency"         # col 9
    ]

    # Filtra le risorse
    df_small = df[df["label"] == LABEL_SMALL]
    df_medium = df[df["label"] == LABEL_MEDIUM]
    df_large = df[df["label"] == LABEL_LARGE]

    # Throughput
    T_small = calc_throughput(df_small)
    T_medium = calc_throughput(df_medium)
    T_large = calc_throughput(df_large)

    # Normalized throughput
    x_small = T_small / t["fair_small"]
    x_medium = T_medium / t["fair_medium"]
    x_large = T_large / t["fair_large"]

    # Fairness index
    xs = [x_small, x_medium, x_large]
    n = 3
    FI = (sum(xs)**2) / (n * sum([x**2 for x in xs]))

    # Output
    print(f"Throughput SMALL : {T_small:.2f} req/s")
    print(f"Throughput MEDIUM: {T_medium:.2f} req/s")
    print(f"Throughput LARGE : {T_large:.2f} req/s\n")

    print(f"x_small : {x_small:.3f}")
    print(f"x_medium: {x_medium:.3f}")
    print(f"x_large : {x_large:.3f}\n")

    print(f">>> FAIRNESS INDEX = {FI:.4f}")
    print("===========================================\n")
