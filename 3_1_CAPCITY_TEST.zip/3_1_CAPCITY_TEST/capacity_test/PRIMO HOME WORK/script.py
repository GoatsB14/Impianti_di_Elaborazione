import os
import re
import pandas as pd
import matplotlib.pyplot as plt

# === CONFIG ===
input_dir = "."  # cartella dei CSV
pattern = re.compile(r"run_(\d+)_ctt_(\d+)\.csv")
results_raw = []

# === LETTURA FILE ===
for file in os.listdir(input_dir):
    match = pattern.match(file)
    if not match:
        continue

    run_number = int(match.group(1))
    ctt = int(match.group(2))

    # --- FILTRA SOLO CTT >= 900 ---
    if ctt < 900:
        continue

    path = os.path.join(input_dir, file)
    df = pd.read_csv(path)

    # --- Throughput ---
    start_time = df["timeStamp"].min()
    end_time = df["timeStamp"].max()
    duration_s = (end_time - start_time) / 1000
    total_requests = len(df)
    throughput = total_requests / duration_s if duration_s > 0 else 0

    # --- Avg RT ---
    avg_rt_ms = df["elapsed"].mean()
    avg_rt_s = avg_rt_ms / 1000

    # --- Power ---
    power = throughput / avg_rt_s if avg_rt_s > 0 else 0

    results_raw.append({
        "CTT": ctt,
        "Run": run_number,
        "Throughput": throughput,
        "AvgRT_ms": avg_rt_ms,
        "Power": power
    })

# Converti in DataFrame
df_raw = pd.DataFrame(results_raw)

# === MEDIA PER CTT SU DUE RUN ===
summary = df_raw.groupby("CTT").agg({
    "Throughput": "mean",
    "AvgRT_ms": "mean",
    "Power": "mean"
}).reset_index()

summary = summary.sort_values("CTT")
summary.to_csv("RISULTATI_FINALI.csv", index=False)

print("\n=== RISULTATI FINALI (MEDIA SU 2 RUN) ===")
print(summary)

# Prepara ticks ogni 100
max_ctt = summary["CTT"].max()
xticks = list(range(900, max_ctt + 1, 100))

# === FUNZIONE PER AGGIUNGERE LE DUE LINEE ===
def add_vertical_lines():
    plt.axvline(x=1500, color='green', linestyle='-', linewidth=2)
    plt.axvline(x=1900, color='red', linestyle='-', linewidth=2)

# === GRAFICI ===

# 1) Throughput
plt.figure()
plt.plot(summary["CTT"], summary["Throughput"], marker='o', linewidth=2)
add_vertical_lines()
plt.title("Throughput vs CTT")
plt.xlabel("CTT (richieste simultanee)")
plt.ylabel("Throughput (req/s)")
plt.grid(True)
plt.xticks(xticks)
plt.savefig("throughput_vs_ctt.png")

# 2) Response Time
plt.figure()
plt.plot(summary["CTT"], summary["AvgRT_ms"] / 1000, marker='s', linewidth=2)
add_vertical_lines()
plt.title("Average Response Time vs CTT")
plt.xlabel("CTT (richieste simultanee)")
plt.ylabel("Average RT (s)")
plt.grid(True)
plt.xticks(xticks)
plt.savefig("response_vs_ctt.png")

# 3) Power
plt.figure()
plt.plot(summary["CTT"], summary["Power"], marker='^', linewidth=2)
add_vertical_lines()
plt.title("Power vs CTT")
plt.xlabel("CTT (richieste simultanee)")
plt.ylabel("Power")
plt.grid(True)
plt.xticks(xticks)
plt.savefig("power_vs_ctt.png")

plt.show()