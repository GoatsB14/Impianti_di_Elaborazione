import os
import re
import numpy as np
import matplotlib.pyplot as plt

# ================== CONFIGURAZIONE ==================

input_dir = "."  # cartella con i file vmstat_ctt*_2.txt
pattern = re.compile(r"vmstat_ctt(\d+)_2\.txt")  # es: vmstat_ctt1700_2.txt

# nomi colonna (ordine standard vmstat)
COLUMNS = [
    "r", "b",
    "swpd", "free", "buff", "cache",
    "si", "so",
    "bi", "bo",
    "in", "cs",
    "us", "sy", "id", "wa", "st"
]

# ================== LETTURA FILE ==================

results = {}  # ctt -> dict(colonna -> media)

for fname in os.listdir(input_dir):
    m = pattern.match(fname)
    if not m:
        continue

    ctt = int(m.group(1))
    path = os.path.join(input_dir, fname)

    rows = []

    with open(path, "r") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue

            # salta gli header
            if line.startswith("procs") or line.startswith("r  b") or "-system-" in line:
                continue

            parts = line.split()

            # ci interessano solo le righe con almeno 17 numeri
            if len(parts) < 17:
                continue

            try:
                vals = list(map(int, parts[:17]))
            except ValueError:
                # se ci sono parole strane nella riga, la saltiamo
                continue

            rows.append(vals)

    if not rows:
        print(f"[ATTENZIONE] Nessun dato valido letto da {fname}")
        continue

    data = np.array(rows)
    means = dict(zip(COLUMNS, data.mean(axis=0)))
    results[ctt] = means
    print(f"Letto {fname}: {len(rows)} righe valide")

if not results:
    print("Nessun file vmstat_ctt*_2.txt trovato o nessun dato valido.")
    exit(0)

# ================== PREPARA SERIE PER I GRAFICI ==================

ctts = sorted(results.keys())

def serie(col):
    return [results[ctt][col] for ctt in ctts]

# ================== PLOTTAGGIO ==================

plt.figure(figsize=(18, 12))

# 1) CPU: us, sy, id, wa, st
ax1 = plt.subplot(2, 3, 1)
for col in ["us", "sy", "id", "wa", "st"]:
    ax1.plot(ctts, serie(col), marker="o", label=col)
ax1.set_title("Media dei parametri per il gruppo cpu")
ax1.set_xlabel("CTT")
ax1.set_ylabel("Media")
ax1.legend()
ax1.grid(True)

# 2) IO: bi, bo
ax2 = plt.subplot(2, 3, 2)
for col in ["bi", "bo"]:
    ax2.plot(ctts, serie(col), marker="o", label=col)
ax2.set_title("Media dei parametri per il gruppo io")
ax2.set_xlabel("CTT")
ax2.set_ylabel("Media")
ax2.legend()
ax2.grid(True)

# 3) MEMORY: swpd, free, buff, cache
ax3 = plt.subplot(2, 3, 3)
for col in ["swpd", "free", "buff", "cache"]:
    ax3.plot(ctts, serie(col), marker="o", label=col)
ax3.set_title("Media dei parametri per il gruppo memory")
ax3.set_xlabel("CTT")
ax3.set_ylabel("Media")
ax3.legend()
ax3.grid(True)

# 4) PROCS: r, b
ax4 = plt.subplot(2, 3, 4)
for col in ["r", "b"]:
    ax4.plot(ctts, serie(col), marker="o", label=col)
ax4.set_title("Media dei parametri per il gruppo procs")
ax4.set_xlabel("CTT")
ax4.set_ylabel("Media")
ax4.legend()
ax4.grid(True)

# 5) SWAP: si, so
ax5 = plt.subplot(2, 3, 5)
for col in ["si", "so"]:
    ax5.plot(ctts, serie(col), marker="o", label=col)
ax5.set_title("Media dei parametri per il gruppo swap")
ax5.set_xlabel("CTT")
ax5.set_ylabel("Media")
ax5.legend()
ax5.grid(True)

# 6) SYSTEM: in, cs
ax6 = plt.subplot(2, 3, 6)
for col in ["in", "cs"]:
    ax6.plot(ctts, serie(col), marker="o", label=col)
ax6.set_title("Media dei parametri per il gruppo system")
ax6.set_xlabel("CTT")
ax6.set_ylabel("Media")
ax6.legend()
ax6.grid(True)

plt.tight_layout()
plt.show()